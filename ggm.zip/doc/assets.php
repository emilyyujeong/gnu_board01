<?
$as_company = '깔끄미청소';
$as_tel = '051-783-2317';
$as_mail = 'emilyyujeong@gmail.com';
$as_address = '경상북도 울진군 후포면 후포리 145';
$as_company_number = '067-09-424';
$as_name = '홍길동';
$as_slogan = '부산 아파트입주청소 이사청소 ';
$as_description = '부산 아파트입주청소 부산 양산 김해 기장 아파트입주청소 이사청소 오피스텔청소 상가청소 전문업체';
$as_color = ['#da544b','#f4cb4f','#337689','#6fa476'];

?>