<ul>
   <li><a href="<?php echo G5_THEME_URL ?>/doc/m011.php">깔끄미청소 소개</a></li>
   <li><a href="<?php echo G5_THEME_URL ?>/doc/m012.php">아파트입주청소</a></li>
   <li><a href="<?php echo G5_THEME_URL ?>/doc/m013.php">이사/상가청소</a></li>
   <li><a href="<?php echo G5_THEME_URL ?>/doc/m014.php">사무실청소</a></li>
   <li><a href="/bbs/board.php?bo_table=gallery">청소갤러리</a></li>
   <li><a href="/bbs/board.php?bo_table=qa">질문과답변</a></li>
</ul>

                  