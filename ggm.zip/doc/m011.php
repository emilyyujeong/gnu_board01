<?php
include_once('../../../common.php');
$num = 1;
$title = '깔끄미청소 소개';
include_once(G5_THEME_PATH.'/head.php');
?>

<div class="sub">
    <img src="../images/logo2.png" alt="">
   Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt adipisci quia dignissimos inventore assumenda numquam laudantium error sed doloremque aliquam repellendus ut consequatur, reiciendis obcaecati soluta iste ipsum placeat deserunt.
</div>


<?php
include_once(G5_THEME_PATH.'/tail.php');